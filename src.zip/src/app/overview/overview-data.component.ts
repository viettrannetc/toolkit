import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forEachChild } from 'typescript';
import { Data } from '@angular/router';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-overview-data',
  templateUrl: './overview-data.component.html'
})


export class OverviewDataComponent {
  public wps: ToolkitWorkpackage[];
  public iterations: ToolkitIteration[];
  public allocations: ToolkitAllocation[];
  public allocationadjustments: ToolkitAllocationAdjustment[];
  public features: ToolkitFeature[];
  public iterationPlanning;
  public overview;

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {

    
    
    http.get(baseUrl + 'toolkit/overview/iterations').subscribe(result => {
      this.overview = result;
    }, error => console.error(error));

    http.get<ToolkitFeature[]>(baseUrl + 'toolkit/feature').subscribe(result => {
      this.features = result;
    }, error => console.error(error));


    //http.get<ToolkitWorkpackage[]>(baseUrl + 'toolkit/wp').subscribe(result => {
    //  this.wps = result;
    //}, error => console.error(error));


    //http.get<ToolkitIteration[]>(baseUrl + 'toolkit/iteration').subscribe(result => {
    //  this.iterations = result;
    //}, error => console.error(error));


    //http.get<ToolkitAllocation[]>(baseUrl + 'toolkit/allocation').subscribe(result => {
    //  this.allocations = result;
    //}, error => console.error(error));


    //http.get<ToolkitAllocationAdjustment[]>(baseUrl + 'toolkit/allocationadjustment').subscribe(result => {
    //  this.allocationadjustments = result;
    //}, error => console.error(error));


  }

  public parseDate(input) {
    var parts = input.match(/(\d+)/g);
    // new Date(year, month [, date [, hours[, minutes[, seconds[, ms]]]]])
    return new Date(parts[0], parts[1] - 1, parts[2]); // months are 0-based
  }
  public WithoutTime(dateTimeString) {
    var dateTime = this.parseDate(dateTimeString);
    var date = new Date(dateTime.getTime());
    date.setHours(0, 0, 0, 0);
    return date;
  }
  public getWeekNumber(d): number {
    // Copy date so don't modify original
    d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    // Set to nearest Thursday: current date + 4 - current day number
    // Make Sunday's day number 7
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
    // Get first day of year
    var yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1)).valueOf();
    // Calculate full weeks to nearest Thursday
    var weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
    // Return array of year and week number

    //return [d.getUTCFullYear(), weekNo];
    return weekNo;
  }

  public isWeekend(today: Date): boolean {
    if (today.getDay() === 6 || today.getDay() === 0) return true;

    return false;
  }

  public addDays(currentDate: Date, days: number): Date {
    var futureDate = new Date();
    futureDate.setDate(currentDate.getDate() + days);
    return futureDate;
  }


  public async handleEachIteration(expectedIteration: ToolkitIteration) {
    var people;
    var workpackages;
    var iterationId;
    var iterationName;

    var workingDaysInIteration: Date[] = [];

    //var expectedIteration = this.iterations.filter(it => it.id === expectedIteration.id)[0];


    var currentDate: Date = this.WithoutTime(expectedIteration.startDate);
    var endDate: Date = this.WithoutTime(expectedIteration.endDate);

    expectedIteration.weeks = [];
    while (currentDate <= endDate) {
      var week = this.getWeekNumber(currentDate);

      if (expectedIteration.weeks.indexOf(week) <= -1) {
        expectedIteration.weeks.push(week);
      }

      if (this.isWeekend(currentDate) === false) {
        workingDaysInIteration.push(currentDate);
      }
      currentDate = this.addDays(currentDate, 1);
    }




    ////working hours & working days
    //var teamNameBySelectedIteration = expectedIteration.team.lookupValue;
    //var allocationsByTeam = this.allocations.filter(a => a.team.lookupValue === teamNameBySelectedIteration);
    //var allocationAdjustmentByTeam = this.allocationadjustments.filter(a => a.team.lookupValue === teamNameBySelectedIteration);

    //for (var i = 0; i < allocationsByTeam.length; i++) {
    //  var allocationMemberByTeam = allocationsByTeam[i];
    //  var member: IterationMember = {
    //    name: allocationMemberByTeam.resource.lookupValue,
    //    assignedHours: 0,
    //    availableHours: 0,
    //    nonWorkingDays: [],
    //    tasks: [],
    //    workingDays: []
    //  };
    //  //member.name = allocationMemberByTeam.resource.lookupValue;

    //  var adjustment = allocationAdjustmentByTeam.filter(ad => ad.resource.lookupValue === member.name);

    //  for (var w = 0; w < workingDaysInIteration.length; w++) {
    //    var workingDay = workingDaysInIteration[w];

    //    if (this.WithoutTime(allocationMemberByTeam.dateFrom) <= workingDay && workingDay <= this.WithoutTime(allocationMemberByTeam.dateTo)) {

    //      var workingHours = allocationMemberByTeam.hoursCapacity;
    //      for (var ad = 0; ad < adjustment.length; ad++) {
    //        var allocationAdjustmentMemberByTeam = adjustment[ad];
    //        if (this.WithoutTime(allocationAdjustmentMemberByTeam.dateFrom) <= workingDay && workingDay <= this.WithoutTime(allocationAdjustmentMemberByTeam.dateTo)) {
    //          //member.AvailableHours = member.AvailableHours - allocationAdjustmentMemberByTeam.HoursCapacity;
    //          workingHours = workingHours - allocationAdjustmentMemberByTeam.hoursCapacity;
    //          member.nonWorkingDays.push(workingDay);
    //        }
    //      }

    //      if (workingHours > 0) {
    //        member.workingDays.push(workingDay);
    //        member.availableHours += workingHours;
    //      }
    //    }
    //  }


    //  //work packages
    //  var workpackagesInIteration = this.wps.filter(wp => wp.wpIterationId === expectedIteration.id);
    //  var workpackagesByUserInIteration = workpackagesInIteration.filter(wp => wp.wpAssignee === member.name);

    //  for (var wpi = 0; wpi < workpackagesByUserInIteration.length; wpi++) {
    //    var wp = workpackagesByUserInIteration[wpi];
    //    member.tasks.push(wp);
    //    member.assignedHours += wp.wpRemainingHour;
    //  }

    //  var planning: IterationPlanning = { members: [] };
    //  planning.members.push(member);
    //  expectedIteration.planning = planning;//.members.push(member);
    //}

    //this.iterations.push(expectedIteration);
    //return expectedIteration;
  }

  public async handleData() {
    for (var i = 0; i < this.iterations.length; i++) {
      var iteration = this.iterations[i];
      this.handleEachIteration(iteration);
      //var planningIteration = this.iterationPlanning.filter(it => it.IterationName == iteration.title);
      //if (planningIteration == null) {

      //  //planningIteration = this.handleEachIteration(iteration);

      //  //var allocatedWps = _wpItemsLocal.Where(w => !string.IsNullOrEmpty(w.WPIterationId) && int.Parse(w.WPIterationId) == iteration.Id).ToList();
      //  //planningIteration.RefreshWp(allocatedWps);

      //  //planningIteration.Add(planningIteration);
      //}
    }
  }


  public filterByFeature(iteration, featureId) {    
    var result = iteration.workPackages.filter(x => x.featureId.toString() === featureId.toString());
    return result;
  }


  drop(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
  }

  allowDrop(ev) {
    ev.preventDefault();
  }

  drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
  }


  //onDrop(event: any) {
  //  event.preventDefault();
  //  event.stopPropagation();
  //  // your code goes here after droping files or any
  //}

  //onDragOver(evt) {
  //  evt.preventDefault();
  //  evt.stopPropagation();
  //}

  //onDragLeave(evt) {
  //  evt.preventDefault();
  //  evt.stopPropagation();
  //}
}

interface ToolkitData {
  date: ToolkitIterationsPlanning[];
  iteration: ToolkitIteration[];
}

interface ToolkitLookupModel {
  lookupId: number;
  lookupValue: string;
}

interface ToolkitWorkpackage {
  team: ToolkitLookupModel;
  resource: ToolkitLookupModel;
  title: string;
  dateFrom: Date;
  dateTo: Date;
  hoursCapacity: number;

  featureId: number;
  feature: string;
  featureShow: string;

  usId: number;
  us: string;
  usShow: string;

  wpId: number;
  wpTitle: string;
  wpShow: string;

  wpType: string;
  wpStart: Date;
  wpDueDate: Date;
  wpStatus: string;
  wpTeam: string;
  wpAssignee: string;
  wpEstimate: number;
  wpRemainingHour: number;
  wpIterationId: number;
  wpIterationName: string;
  wpSpentHour: number;
  wpDependOn: number;

}

interface ToolkitAllocationAdjustment {
  team: ToolkitLookupModel;
  resource: ToolkitLookupModel;
  title: string;
  dateFrom: Date;
  dateTo: Date;
  hoursCapacity: number;
}

interface ToolkitAllocation {
  team: ToolkitLookupModel;
  resource: ToolkitLookupModel;
  title: string;
  dateFrom: Date;
  dateTo: Date;
  hoursCapacity: number;
}

interface ToolkitIteration {
  id: number;
  team: ToolkitLookupModel;
  title: string;
  startDate: Date;
  endDate: Date;

  planning: IterationPlanning;
  weeks: number[];
}

interface IterationPlanning {
  members: IterationMember[];
}

interface IterationMember {
  name: string;
  availableHours: number;
  workingDays: Date[];
  nonWorkingDays: Date[];

  assignedHours: number;
  tasks: ToolkitWorkpackage[];
}

interface ToolkitIterationsPlanning {
  Year: number;
  Month: number;
  Weeks: number[];
  IterationId: number;
  IterationName: string;
  AvailableHours: number;
  Workload: number;
  AllocatedHours: number;
  Status: IterationPlanningStatus;
}


interface IterationPlanningStatus {
  color: string;
  tooltip: string;
}

interface ToolkitFeature {
  id: number;
  name: string;
}
